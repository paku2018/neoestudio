<!-- Header -->
@include('header')
<!-- Sidebar -->
@include('sidebar')
@yield('content')


@include('footer')
@yield('javascript')