
<html>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

 
  </head>
  <body>
    <div style="text-align: center;">
    <div style="text-align: center; border: 1px solid lightgrey;">
<h2>Detalles DeContacto</h3>
          <p style="font-size: larger;">Nombre y apellidos &nbsp;&nbsp;:&nbsp;&nbsp;<b>{{$name}}</b></p>
<p style="font-size: larger;">Correo electrónico &nbsp;&nbsp;:&nbsp;&nbsp;<b>{{$email}}</b></p>

<p style="font-size: larger;">Asunto &nbsp;&nbsp;:&nbsp;&nbsp;<b>{{$affair}}</b></p>
<p style="font-size: larger;">Mensaje &nbsp;&nbsp;:&nbsp;&nbsp;<b>{{$mess}}</b></p>

<br>
<img src="http://95.179.208.227/acadmy/public/neostudio/Logo.png" style="width: 120px;">
    </div>
  </div>


  </body>
</html>