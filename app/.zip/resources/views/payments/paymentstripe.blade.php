<?php 
echo $_GET['subscr_plan'];

?>