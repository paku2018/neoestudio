@extends('dashboard')
@section('content')
<p>mughees</p>
@endsection