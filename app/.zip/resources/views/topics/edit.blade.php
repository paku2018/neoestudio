@extends('dashboard')
@section('content')

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">@lang('lng.Edit Topics')</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('home')}}">@lang('lng.Home')</a></li>
              <li class="breadcrumb-item active"><a href="{{url('topics/edit/'.$topic->id)}}">@lang('lng.Edit Topics')</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
     @if (\Session::has('message'))
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-check"></i> @lang('lng.Alert')!</h5>
          {!! \Session::get('message') !!}
    </div>
    @endif
    <section class="content">
      <div class="row">
        <div class="col-12">
          <form method="POST" action="{{url('topics/update/'.$topic->id)}}" enctype="multipart/form-data">
            {{ csrf_field() }}
                <div class="card-body container" style="width: 50%">
                  <div class="form-group">
                    <label for="name">@lang('lng.Name')</label>
                    <input type="text" class="form-control" name="name"  placeholder="@if(!empty($topic)){{$topic->name}}@endif" value="@if(!empty($topic)){{$topic->name}}@endif" required>
                  </div>
                  <div class="form-group">
                    <label>@lang('lng.Student Type')</label>
                    <select class="form-control" name="studentType">
                      @if($topic->studentType=="Prueba")
                      <option selected value="@lang('lng.Trial')">@lang('lng.Trial')</option>
                      <option value="@lang('lng.First Year')">@lang('lng.First Year')</option>
                      <option value="@lang('lng.Second Year')">@lang('lng.Second Year')</option>
                      @endif
                      @if($topic->studentType=="Alumno")
                      <option value="@lang('lng.Trial')">@lang('lng.Trial')</option>
                      <option selected value="@lang('lng.First Year')">@lang('lng.First Year')</option>
                      <option value="@lang('lng.Second Year')">@lang('lng.Second Year')</option>
                      @endif
                      @if($topic->studentType=="Alumno Convocado")
                      <option value="@lang('lng.Trial')">@lang('lng.Trial')</option>
                      <option value="@lang('lng.First Year')">@lang('lng.First Year')</option>
                      <option selected value="@lang('lng.Second Year')">@lang('lng.Second Year')</option>
                      @endif
                    </select>
                  </div>
                  
                  <?php
                    $courses=\App\Course::all();
                   ?>
                   @if(!empty($courses))
                   <div class="form-group">
                    <label for="exampleInputFile">@lang('lng.Courses')</label>
                    <select class="form-control" name="courseId">
                      @foreach($courses as $course)
                        @if($course->id==$topic->courseId)
                          <option value="{{$course->id}}" selected>{{$course->name}}</option>
                        @endif
                        @if($course->id!=$topic->courseId)
                          <option value="{{$course->id}}">{{$course->name}}</option>
                        @endif
                      @endforeach
                    </select>
                  </div>
                  @endif
                  
                  
                  
                  
                
                 

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">@lang('lng.Submit')</button>
                </div>
              </form>
          <!-- /.card -->

          
          <!-- /.card -->
        </div>
      </div>
    </section>
</div>


@endsection
@section('javascript')
<script type="text/javascript">
  $("#topics").css('background-color','#6c757d');
</script>
<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});
</script>
@endsection