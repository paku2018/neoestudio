<div class="container" style="position: relative; margin-top: 7%; font-size: larger">
<div style="float:left;">
<img src="/home/neoestudioguardiaciviloposici/www/l2.png" style="width: 150px;">
</div>
<div style="float:right;">
  <p>Teléfono <b>965001999</b><br>Whatsapp: <b>621231350</b><br>Lunes-
          Viernes de 9 a 14h</p>
</div>
<br>
<br><br><br><br><br><br>
<div style="text-align: center">
  <p><b>Código estudiantil</b>&nbsp;:&nbsp;{{$studentCode}}</p>
  <p><b>contraseña</b>&nbsp;:&nbsp;{{$password}}</p>
  <p><b>Precio</b>&nbsp;:&nbsp;{{$amount}}</p>
  <p><b>Hora</b>&nbsp;:&nbsp;{{$type}}</p>
  <p><b>Tipo</b>&nbsp;:&nbsp;{{$time}}</p>
</div>

  <br><br><br>
  <div style="">
    <p style="text-align: center;">© 2020 Neoestudio Academia Online S.L. <br>Todos los derechos reservados</p>
  </div>
</div>