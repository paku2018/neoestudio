<!doctype html>
<html lang="en">
  
  </head>
  <body>
    <div style="margin-left: 25%; margin-right: 25%;">
      <div class="row">
        <div class="col-md-6">
          <h1 style="float: left;">Factura</h1>
        </div>
        <div class="col-md-6">
          <img src="http://95.179.208.227/acadmy/public/neostudio/Logo.png" style="width: 30%; float: right;">
        </div>
      </div>
  
  <div class="row">
    <div class="col-md-6" style="">
      <p style="text-align: left;">NEOESTUDIO ACADEMIA ONLINE S.L.U<br>
        CIF: B42651109<br>
        C/ GUADALEST 11, 3 C<br>
        CP: 03005 Alicant (Alicant)
      </p>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      
    </div>
    <div class="col-md-6" style="">
      
      <ul style="display: table;width: 100%;table-layout: fixed; font-size: smaller;">
        <li style="display: table-cell; background-color: black;color: white;text-align: center;border-right: 1px solid white"><b>FACTURA N</b> 10266</li>
        <li style="display: table-cell; background-color: black;color: white;text-align: center;"><b>FECHA</b> 19/01/2020</li>
      </ul>
    </div>
    </div>

    
  
    </div>
   
  </body>
</html>